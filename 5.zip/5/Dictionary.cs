﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesPart1
{
    public enum SpeedUnit { kmH=1, kn, mS, kmS };
}
